import sys,os,datetime,colorama,time
from colorama import Style,Fore,Back

def customer_name():
	return input("\nYour Name : ")

def display_stock():
	print(f'\n{Fore.CYAN}. . . . . . . . . . . . . . . . . . . .. . . . . . .  .. . . .  . . . .. \n')
	for items in stock:
		print(f'{items} = Rs.{stock.get(items)}')# Displaying the Stock in a Format
	print(f'\n{Fore.CYAN}. . . . . . . . . . . . . . . . . . . .. . . . . . .  .. . . .  . . . .. ')

def display_menu():
		print(f"""
			\n1.Display Stock 
			\n2.Add Item
			\n3.Delete Items
			\n4.Update Quantity
			\n5.Exit
			""")

def take_menu_choice():
	try: 
		operation = int(input("\nEnter Your Choice : "))
		if operation < 0 or operation > 5:
			return take_menu_choice()
		else:
			return operation
	except ValueError:
		return take_menu_choice()


def take_item():
	item_func = input("\nEnter Your Item Name : ")
	return item_func[0].upper() + item_func[1:].lower()

def take_index():
	try:
		index= int(input("\nEnter the Index No: "))
		return index
	except ValueError:
		return take_index()

def delete_item(index):
	try:
		if 0 < index <= len(user_bought_index) :# SO that the index is not 0 and greater than the index No
			del user_bought_item[index-1]
			del user_bought_price[index-1]
			del user_bought_quantity[index-1]
			del user_bought_index[index-1]
		else:
			print("\nIndex out of range!")
			time.sleep(1)
	except IndexError:
		print("\nIndex doesnot Exist!")
		time.sleep(1)


def search(item):
	if item in stock:
		print(f'\n{item} In Stock!\nPrice: Rs. {stock.get(item)}')
		return True
	else:
		print(f'\n{item} not in Stock! ')
		return False

def update_quan(index):
	try:
		if  0 < index <= len(user_bought_index): #If index is greater than 0 and smaller than its Length
			new_quan = quan_num_new()
			if new_quan !=0 and new_quan >0:
				del user_bought_quantity[index - 1]
				user_bought_quantity.insert(index - 1,new_quan) 
				del user_bought_price[index - 1]
				price = check_prices(user_bought_item[index - 1])
				user_bought_price.insert(index - 1, calculate(price, new_quan))
			else:
				delete_item(index)

		else:
			print("Index Does not Exist! ")
			time.sleep(1)
	except ValueError:
		return update_quan()



def quan_num(): # To get Quantity for Adding
	try:
		num = int(input("\nQuantity : "))
		if num < 0:
			return quan_num()
		else:
			return num
	except ValueError:
		return quan_num()


def quan_num_new(): #To get New Quantity for Updating 
	try:
		num = int(input("\nNew Quantity : "))
		if num < 0:
			return quan_num_new()
		else:
			return num
	except ValueError:
		return quan_num_new()


def check_prices(item):
	if item in stock:
		return stock.get(item)

def calculate(product_price,quantity):
	return product_price*quantity

#Formatting on a file and terminal are different
def print_bill():
	print(f"{Style.BRIGHT}\nIndex No\tItem\t\tQuantity\tPrice\t\tTotal Price")
	#Matching the Upper Format
	for x in range(len(user_bought_index)):
		if user_bought_quantity[x] !=0:
			print(f"\n{x+1}      \t\t{user_bought_item[x]}\t\t{user_bought_quantity[x]}\t\t{stock.get(user_bought_item[x])}\t\t{user_bought_price[x]}")
		else:
			continue

def print_date_time():
	if len(user_bought_price) > 0: #Checking if user bought anything 
		print(f'\nTotal Amount : Rs.{user_bought_price[-1]}')
		print(f'Time : {datetime.datetime.now().strftime("%d-%m-%Y %I:%M %p")}') 
	elif len(user_bought_price) ==0: #Print Bill Rs.0 otherwise
		print(f'\nTotal Amount : Rs.0 ')
		print(f'Time : {datetime.datetime.now().strftime("%d-%m-%Y %H:%M %p")}')


#Because file doesnot consider too many spaces
def print_bill_file():
	print("\nIndex No Item\tQuantity Price\tTotal Price")
	#Matching the Upper Format
	for x in range(len(user_bought_item)):
		print(f"\n{x+1}\t{user_bought_item[x]}\t{user_bought_quantity[x]}\t{stock.get(user_bought_item[x])}\t{user_bought_price[x]}")



colorama.init(autoreset = True)

stock={}
stock_file = "C:\\Users\\amc\\Downloads\\Items.txt"
#Reading the stock and price from file and storing it in dictionary stock{}
with open(stock_file,"r") as file:
	for line in file:
		name , value = line.strip().split(':')
		name 	= name.strip()
		name =  name[0].upper() + name[1:].lower()
		value = int(value.strip())
		stock[name] = value

file.close()

print(f"""{Style.BRIGHT} {Fore.RED}
\n						Welcome to X Grocery Store 
. . . . . .. . . . . . . . . . . . . .. . . . . . . . . .. . . . . . . . . .. . . . . . .  . . .. . . . . . . . . .. . .
						 """) 

user_bought_price	 = 	[]
user_bought_item  	 =	[]
user_bought_quantity = 	[]
user_bought_index 	 =  []


name = customer_name()
display_menu()
choice = take_menu_choice()

count = 1 # For Generate Indexes

while choice != 5:
	if choice == 1 : #if to display stock
		display_stock()
		display_menu()
		choice = take_menu_choice()

	elif choice ==2: #if to add item
		user_req = take_item() 
		searching = search(user_req)
		quantity = 0

		if searching == True: #if item exists in stock	
			quantity = quan_num() 

			if user_req not in user_bought_item:
				user_bought_index.append(int(count)) #adding all the things to their lists respectively
				count += 1
				user_bought_item.append(user_req)	
				user_bought_quantity.append(quantity)
				user_bought_price.append(calculate(check_prices(user_req),quantity))
				os.system('cls') #clearing the screen
				print_bill()
				display_menu()
				choice = take_menu_choice()

			else:
				index_of_item = user_bought_item.index(user_req) #Taking index so i can exchange values
				prev_quantity = user_bought_quantity[index_of_item ] #To keep track of previous quantity
				del user_bought_quantity[index_of_item]
				del user_bought_price[index_of_item]
				user_bought_quantity.insert(index_of_item, prev_quantity+ quantity)
				price = check_prices(user_req)
				user_bought_price.insert(index_of_item, calculate(price,prev_quantity+quantity))
				os.system('cls') #clearing the screen
				print_bill()
				display_menu()
				choice = take_menu_choice()	

		else:
			time.sleep(1)
			os.system('cls')
			if len(user_bought_index) !=0:
				print_bill()
				display_menu()
				choice = take_menu_choice()
			else:
				display_menu()
				choice = take_menu_choice()

	elif choice == 3: #if user wants to delete
		get_index = take_index()
		delete_item(get_index)
		count -=1 #Minus index by 1 to keep count of Index No
		os.system('cls')
		if len(user_bought_index) !=0:
			print_bill()
			display_menu()
			choice = take_menu_choice()
		else:
			display_menu()
			choice = take_menu_choice()

	elif choice == 4:
		get_index = take_index()
		update_quan(get_index)
		os.system('cls')
		if len(user_bought_index) !=0:
			print_bill()
			display_menu()
			choice = take_menu_choice()
		else:
			display_menu()
			choice = take_menu_choice()


# To clear space for printing the Bill
os.system('cls')

#Making a new index so i can add all the values of the indexes in the last one
user_bought_price.append(0)

#Adding all the indexes of list to its last index as you cannot iterate integer with lists
for x in range(len(user_bought_price)-1):
	user_bought_price[len(user_bought_price) -1] += user_bought_price[x]


#Starting to Print the Total Bill of the Customer
print(f"\n{Style.BRIGHT}Customer Name : {Style.NORMAL} {name}")
print_bill()
print_date_time()
print(f'{Style.BRIGHT} {Fore.RED}\n. . . . . . . . . . . . . . . . Thanks For Shopping . . . .. . . . . . .  .. . . .  . . . .. ')


sales_file = "C:\\Users\\amc\\Downloads\\Sales.txt"

with open(sales_file,"a") as file:
	sys.stdout= file
	print('\n. . . . . . . . . . . . . . . . . . . .. . . . . . .  .. . . .  . . . .. . . . . . . .  . . . . . . .')
	print(f"\nCustomer Name : {name}")
	print_bill_file()
	print_date_time()
	print('\n. . . . . . . . . . . . . . . . . . . .. . . . . . .  .. . . .  . . . ..  . . . . . . . . . . . . . . . ')
	sys.stdout= sys.__stdout__


file.close()

def get_data(): 
    with open("C:\\Users\\amc\\Downloads\\Sales.txt", "r") as file:
        return file.read().split("\t") #Taking data from the file and storing it in lists by breaking it at a tab

lists = get_data()

demand_file = "C:\\Users\\amc\Downloads\\Demand.txt"


sorted_dict ={} 

with open(demand_file,"w") as file:
	
	count = 0

	for items in stock:
		for words in lists: 
			if items in words: #If item is present in lists then add 1
				count+=1
			
			sorted_dict[items] = count # Add the value(+1) to its Item

		count = 0

	#Sorting the DIctionary in Descending Order	
	sorted_dict = dict(sorted(sorted_dict.items(), key= lambda item : item[1] , reverse =True)) 

	sys.stdout = file

	#Printing the Dictionary into the file
	for items in sorted_dict:
		print(f"{items} : {sorted_dict.get(items)}")


	sys.stdout = sys.__stdout__


		
	




input()

