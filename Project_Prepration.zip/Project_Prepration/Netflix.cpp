#include <iostream>
#include <string>
#include <vector>
#include <queue>
#include <map>
#include <unordered_map>
#include <unordered_set>
#include <algorithm>
#include <limits>
#include <cmath>
#include <cctype>
#include <iomanip>
#include <fstream>

using namespace std;


struct Movie {
	int id;
	string title;
	string genre;
	float rating;
	int year;
	int duration;
	int watchcount;
	Movie* next;

	Movie(int i, string t, string g, float r, int y, int d)
		: id(i), title(t), genre(g), rating(r), year(y), duration(d), watchcount(0), next(nullptr) {}
};

struct StackNode {
	Movie* movie;
	StackNode* next;
	StackNode(Movie* m) : movie(m), next(nullptr) {}
};

struct AVLNode {
	Movie* movie;
	AVLNode* left;
	AVLNode* right;
	int height;
	AVLNode(Movie* m) : movie(m), left(nullptr), right(nullptr), height(1) {}
};

struct Edge {
	string target;
	float weight;
};
string toLower(const string& s) {
	string result = s;
	transform(result.begin(), result.end(), result.begin(), ::tolower);
	return result;
}

//=======Movie Hashtable for fast title-based lookup and prefix recommendations===============
class MovieHashtable {
	private:
		struct HashEntry {
			string key;
			Movie* movie;
			HashEntry(string k, Movie* m) : key(k), movie(m) {}
		};

		vector<vector<HashEntry>> table;
		int size;

		int hashFunction(const string& key) const {
			int hash = 0;
			for (char c : key) {
				hash = (hash * 31 + c) % size;
			}
			return hash;
		}

	public:
		MovieHashtable(int tablesize = 100) : size(tablesize) {
			table.resize(size);
		}

		~MovieHashtable() {
			for (auto& bucket : table) {
				for (auto& entry : bucket) {

				}
			}
		}

		void insertMovie(Movie* movie) {
			if (!movie) return;
			int index = hashFunction(movie->title);
			for (auto& entry : table[index]) {
				if (entry.key == movie->title) {
					entry.movie = movie;
					return;
				}
			}
			table[index].emplace_back(movie->title, movie);
		}

		Movie* findMovie(const string& title) {
			int index = hashFunction(title);
			for (auto& entry : table[index]) {
				if (entry.key == title) {
					return entry.movie;
				}
			}
			return nullptr;
		}

		void incrementWatchcount(const string& title) {
			Movie* movie = findMovie(title);
			if (movie) {
				movie->watchcount++;
			}
		}

		vector<Movie*> getAllMovies() {
			vector<Movie*> movies;
			for (auto& bucket : table) {
				for (auto& entry : bucket) {
					movies.push_back(entry.movie);
				}
			}
			return movies;
		}

		vector<Movie*> getMoviesByPrefix(const string& prefix) {
			vector<Movie*> matches;
			for (auto& bucket : table) {
				for (auto& entry : bucket) {
					if (entry.key.find(prefix) == 0) {
						matches.push_back(entry.movie);
					}
				}
			}
			return matches;
		}

		vector<Movie*> getRecommendations(const string& prefix, int limit = 5) {
			vector<Movie*> candidates = getMoviesByPrefix(prefix);
			if (candidates.empty()) {
				return candidates;
			}

			auto cmp = [](Movie* a, Movie* b) {
				if (a->watchcount != b->watchcount) {
					return a->watchcount < b->watchcount;
				}
				if (a->rating != b->rating) {
					return a->rating < b->rating;
				}
				return a->year < b->year;
			};

			priority_queue<Movie*, vector<Movie*>, decltype(cmp)> pq(cmp);
			for (Movie* movie : candidates) {
				pq.push(movie);
			}

			vector<Movie*> recommendations;
			while (!pq.empty() && recommendations.size() < limit
				recommendations.push_back(pq.top());
				pq.pop();
			}
			return recommendations;
		}
};




//===========AVLTree for filtering=======================
class AVLTree {
	private:
		AVLNode* root;
		bool sortByRating;
		unordered_map<string, vector<Movie*>> genreMap;

		int getHeight(AVLNode* node) {
			return node ? node->height : 0;
		}

		int getBalance(AVLNode* node) {
			return node ? getHeight(node->left) - getHeight(node->right) : 0;
		}

		AVLNode* rightRotate(AVLNode* y) {
			AVLNode* x = y->left;
			AVLNode* T2 = x->right;
			x->right = y;
			y->left = T2;
			y->height = max(getHeight(y->left), getHeight(y->right)) + 1;
			x->height = max(getHeight(x->left), getHeight(x->right)) + 1;
			return x;
		}

		AVLNode* leftRotate(AVLNode* x) {
			AVLNode* y = x->right;
			AVLNode* T2 = y->left;
			y->left = x;
			x->right = T2;
			x->height = max(getHeight(x->left), getHeight(x->right)) + 1;
			y->height = max(getHeight(y->left), getHeight(y->right)) + 1;
			return y;
		}

		AVLNode* insert(AVLNode* node, Movie* movie) {
			if (!node) {
				genreMap[movie->genre].push_back(movie);
				return new AVLNode(movie);
			}

			bool insertLeft = sortByRating ? movie->rating < node->movie->rating : movie->year < node->movie->year;
			if (insertLeft) {
				node->left = insert(node->left, movie);
			} else {
				node->right = insert(node->right, movie);
			}

			node->height = 1 + max(getHeight(node->left), getHeight(node->right));
			int balance = getBalance(node);

			if (balance > 1) {
				bool cond = sortByRating ? movie->rating < node->left->movie->rating : movie->year < node->left->movie->year;
				if (cond) return rightRotate(node);
			}
			if (balance < -1) {
				bool cond = sortByRating ? movie->rating > node->right->movie->rating : movie->year > node->right->movie->year;
				if (cond) return leftRotate(node);
			}
			if (balance > 1) {
				bool cond = sortByRating ? movie->rating > node->left->movie->rating : movie->year > node->left->movie->year;
				if (cond) {
					node->left = leftRotate(node->left);
					return rightRotate(node);
				}
			}
			if (balance < -1) {
				bool cond = sortByRating ? movie->rating < node->right->movie->rating : movie->year < node->right->movie->year;
				if (cond) {
					node->right = rightRotate(node->right);
					return leftRotate(node);
				}
			}

			return node;
		}

		void freeAVL(AVLNode* node) {
			if (!node) return;
			freeAVL(node->left);
			freeAVL(node->right);
			delete node;
		}

	public:
		AVLTree(bool byRating = false) : root(nullptr), sortByRating(byRating) {}

		~AVLTree() {
			freeAVL(root);
		}

		void insert(Movie* movie) {
			root = insert(root, movie);
		}

		void filterByYearRange(AVLNode* node, int startYear, int endYear) {
			if (!node || sortByRating) return;
			if (node->movie->year > startYear) {
				filterByYearRange(node->left, startYear, endYear);
			}
			if (node->movie->year >= startYear && node->movie->year <= endYear) {
				cout << node->movie->title << " (" << node->movie->year << ", Rating: " << node->movie->rating << ", Genre: " << node->movie->genre << ")\n";
			}
			if (node->movie->year < endYear) {
				filterByYearRange(node->right, startYear, endYear);
			}
		}

		void filterByYearRange(int startYear, int endYear) {
			if (sortByRating) {
				cout << "Tree is sorted by rating. Use a year-sorted tree for efficient year filtering.\n";
				return;
			}
			filterByYearRange(root, startYear, endYear);
		}

		void filterByRatingRange(AVLNode* node, float minRating, float maxRating) {
			if (!node || !sortByRating) return;
			if (node->movie->rating > minRating) {
				filterByRatingRange(node->left, minRating, maxRating);
			}
			if (node->movie->rating >= minRating && node->movie->rating <= maxRating) {
				cout << node->movie->title << " (" << node->movie->year << ", Rating: " << node->movie->rating << ", Genre: " << node->movie->genre << ")\n";
			}
			if (node->movie->rating < maxRating) {
				filterByRatingRange(node->right, minRating, maxRating);
			}
		}

		void filterByRatingRange(float minRating, float maxRating) {
			if (!sortByRating) {
				cout << "Tree is sorted by year. Use a rating-sorted tree for efficient rating filtering.\n";
				return;
			}
			filterByRatingRange(root, minRating, maxRating);
		}

		void filterLatestMovies(AVLNode* node, int& count, int N) {
			if (!node || count >= N || sortByRating) return;
			filterLatestMovies(node->right, count, N);
			if (count < N) {
				cout << node->movie->title << " (" << node->movie->year << ", Rating: " << node->movie->rating << ", Genre: " << node->movie->genre << ")\n";
				count++;
			}
			filterLatestMovies(node->left, count, N);
		}

		void filterLatestMovies(int N) {
			if (sortByRating) {
				cout << "Tree is sorted by rating. Use a year-sorted tree for latest movies.\n";
				return;
			}
			int count = 0;
			filterLatestMovies(root, count, N);
		}

		void filterByGenre(const string& genre) {
			string searchKey = toLower(genre);
			bool found = false;

			for (const auto& pair : genreMap) {
				if (toLower(pair.first) == searchKey) {
					found = true;
					for (Movie* movie : pair.second) {
						cout << movie->title << " (" << movie->year << ", Rating: " << movie->rating << ", Genre: " << movie->genre << ")\n";
					}
				}
			}

			if (!found) {
				cout << "No movies found in genre: " << genre << endl;
			}
		}

		void combinedFilter(const string& genre, float minRating, float maxRating, int startYear, int endYear) {
			string searchKey = toLower(genre);
			bool found = false;

			for (const auto& pair : genreMap) {
				if (toLower(pair.first) == searchKey) {
					found = true;
					for (Movie* movie : pair.second) {
						if (movie->year >= startYear && movie->year <= endYear &&
						        movie->rating >= minRating && movie->rating <= maxRating) {
							cout << movie->title << " (" << movie->year << ", Rating: " << movie->rating << ", Genre: " << movie->genre << ")\n";
						}
					}
				}
			}


			if (!found) {
				cout << "No movies found matching all criteria\n";
			}
		}
};






//=========Graph for  recommendations================
class Graph {
	private:
		map<string, vector<Edge>> adjList;
		unordered_map<string, Movie*> movieMap;

	public:
		float calculateWeight(Movie* m1, Movie* m2) {
			float ratingDiff = abs(m1->rating - m2->rating);
			int yearDiff = abs(m1->year - m2->year);
			int durationDiff = abs(m1->duration - m2->duration);
			float weight = 5 * ratingDiff + 1 * yearDiff + 0.1 * durationDiff;
			if (m1->genre != m2->genre) weight += 15;
			else weight -= 5;

			return weight;
		}

		void addEdge(Movie* m1, Movie* m2) {
			float weight = calculateWeight(m1, m2);
			adjList[m1->title].push_back({m2->title, weight});
			adjList[m2->title].push_back({m1->title, weight});
			movieMap[m1->title] = m1;
			movieMap[m2->title] = m2;
		}

		void buildGraph(const vector<Movie*>& movies) {
			adjList.clear();
			movieMap.clear();
			for (size_t i = 0; i < movies.size(); ++i) {
				for (size_t j = i + 1; j < movies.size(); ++j) {
					addEdge(movies[i], movies[j]);

				}
			}
		}

		void recommendSimilarMoviesBFS(const string& startTitle, int maxRecommendations) {
			if (adjList.find(startTitle) == adjList.end()) {
				cout << "Movie not found in graph.\n";
				return;
			}

			unordered_set<string> visited;
			queue<string> q;
			int count = 0;

			q.push(startTitle);
			visited.insert(startTitle);

			cout << "\nRecommended Movies like \"" << startTitle << "\":\n";

			while (!q.empty() && count < maxRecommendations) {
				string current = q.front();
				q.pop();

				for (const Edge& edge : adjList[current]) {
					string title = edge.target;
					if (visited.find(title) == visited.end()) {
						Movie* movie = movieMap[title];
						cout << title << " (" << movie->year << ", Rating: " << movie->rating
						     << ", Genre: " << movie->genre << ", Duration: " << movie->duration << " mins)\n";
						visited.insert(title);
						q.push(title);
						if (++count >= maxRecommendations) break;
					}
				}
			}

			if (count == 0) {
				cout << "No similar movies found.\n";
			}
		}

		void recommendSimilarMoviesDijkstra(const string& startTitle, int topK) {
			if (movieMap.find(startTitle) == movieMap.end()) {
				cout << "Movie not found.\n";
				return;
			}

			map<string, float> dist;
			unordered_set<string> visited;

			for (const auto& pair : movieMap) {
				dist[pair.first] = numeric_limits<float>::infinity();
			}
			dist[startTitle] = 0;

			priority_queue<pair<float, string>, vector<pair<float, string>>, greater<>> pq;
			pq.push({0, startTitle});

			while (!pq.empty()) {
				auto [currDist, currTitle] = pq.top();
				pq.pop();

				if (visited.count(currTitle)) continue;
				visited.insert(currTitle);

				for (const Edge& edge : adjList[currTitle]) {
					string neighborTitle = edge.target;
					float newDist = currDist + edge.weight;
					if (newDist < dist[neighborTitle]) {
						dist[neighborTitle] = newDist;
						pq.push({newDist, neighborTitle});
					}
				}
			}

			vector<pair<float, Movie*>> recommendations;
			for (const auto& pair : dist) {
				if (pair.first != startTitle && pair.second != numeric_limits<float>::infinity()) {
					recommendations.push_back({pair.second, movieMap[pair.first]});
				}
			}

			sort(recommendations.begin(), recommendations.end());

			cout << "\nTop " << topK << " recommendations based on Dijkstra:\n";
			for (int i = 0; i < min(topK, (int)recommendations.size()); ++i) {
				Movie* m = recommendations[i].second;
				cout << m->title << " (Genre: " << m->genre << ", Year: " << m->year
				     << ", Rating: " << m->rating << ", Duration: " << m->duration
				     << ", Score: " << recommendations[i].first << ")\n";
			}
		}
};

StackNode* watchHistoryTop = nullptr;
vector<Movie*> movieList;



//=========Input validation functions===============
string trim(const string& str) {
	const auto strBegin = str.find_first_not_of(" \t\n\r");
	if (strBegin == string::npos) return "";

	const auto strEnd = str.find_last_not_of(" \t\n\r");
	const auto strRange = strEnd - strBegin + 1;

	return str.substr(strBegin, strRange);
}

bool isNumeric(const string& str) {
	return !str.empty() && all_of(str.begin(), str.end(), ::isdigit);
}

string getValidatedString(const string& prompt) {
	string input;
	while (true) {
		cout << prompt;
		if (cin.peek() == '\n') cin.ignore();
		getline(cin, input);
		input = trim(input);
		if (!input.empty() && !isNumeric(input))
			return input;
		else
			cout << "Invalid input. Please enter valid text.\n";
	}
}

float getValidatedRating() {
	float rating;
	while (true) {
		cout << "Enter movie rating (0.0 - 10.0): ";
		cin >> rating;
		if (cin.fail() || rating < 0.0 || rating > 10.0) {
			cin.clear();
			cin.ignore(1000, '\n');
			cout << "Invalid rating. Please enter a number between 0.0 and 10.0.\n";
		} else {
			cin.ignore();
			return rating;
		}
	}
}

int getValidatedInt(const string& prompt, int min = 0, int max = 3000) {
	int value;
	while (true) {
		cout << prompt;
		cin >> value;
		if (cin.fail() || value < min || value > max) {
			cin.clear();
			cin.ignore(numeric_limits<streamsize>::max(), '\n');
			cout << "Invalid number. Please enter a valid value.\n";
		} else {
			cin.ignore(numeric_limits<streamsize>::max(), '\n');
			return value;
		}
	}
}

bool isDuplicate(const string& title, MovieHashtable& movieTable) {
	return movieTable.findMovie(title) != nullptr;
}




//=========Reading from  file=================
void loadMoviesFromFile(const string& filename, int& nextId, MovieHashtable& table, AVLTree& avlRating, AVLTree& avlYear, Graph& graph) {
	ifstream fin(filename);
	if (!fin) {
		cout << "No existing movie file found. Starting fresh.\n";
		return;

	}

	string line;
	while (getline(fin, line)) {
		stringstream ss(line);
		string segment;
		vector<string> tokens;

		while (getline(ss, segment, '|')) {
			tokens.push_back(segment);
		}

		if (tokens.size() != 7) continue;

		int id = stoi(tokens[0]);
		string title = tokens[1];
		string genre = tokens[2];
		float rating = stof(tokens[3]);
		int year = stoi(tokens[4]);
		int duration = stoi(tokens[5]);
		int watchcount = stoi(tokens[6]);

		Movie* movie = new Movie(id, title, genre, rating, year, duration);
		movie->watchcount = watchcount;
		movieList.push_back(movie);
		table.insertMovie(movie);
		avlRating.insert(movie);
		avlYear.insert(movie);

		if (id >= nextId) nextId = id + 1;
	}

	graph.buildGraph(movieList);
	fin.close();
	cout << "Loaded " << movieList.size() << " movies from file.\n";

}




//=========Saving into file=================
void saveMoviesToFile(const string& filename, const vector<Movie*>& movies) {
	ofstream fout(filename);
	for (Movie* m : movies) {
		fout << m->id << "|" << m->title << "|" << m->genre << "|"
		     << m->rating << "|" << m->year << "|" << m->duration << "|"
		     << m->watchcount << "\n";
	}
	fout.close();
}

//========Movie insertion=============
void insertMovie(int& nextId, MovieHashtable& movieTable, AVLTree& avlRating, AVLTree& avlYear, Graph& graph) {
	string more;
	do {
		cin.clear();
		//cin.ignore(numeric_limits<streamsize>::max(), '\n');
		string title = getValidatedString("\nEnter movie title: ");
		if (isDuplicate(title, movieTable)) {
			cout << "Movie already exists. Try a different title.\n";
			return;
		}
		string genre = getValidatedString("Enter movie genre: ");
		float rating = getValidatedRating();
		int year = getValidatedInt("Enter release year (between 1900 and 2025): ", 1900, 2025);
		int duration = getValidatedInt("Enter duration (in minutes)(min:10 min, max:180 min): ", 10, 180);

		Movie* newMovie = new Movie(nextId++, title, genre, rating, year, duration);
		movieList.push_back(newMovie);
		movieTable.insertMovie(newMovie);
		avlRating.insert(newMovie);
		avlYear.insert(newMovie);

		cout << "Movie inserted successfully!\n";
		cout << "Do you want to insert another movie? (Enter \"yes\" if u want/any other key to exit): ";
		getline(cin, more);
	}  while (toLower(more) == "yes" || toLower(more)== "y");


	graph.buildGraph(movieList);
}



//==============Display movies===============
void displayMovies(MovieHashtable& movieTable) {
	vector<Movie*> movies = movieTable.getAllMovies();
	if (movies.empty()) {
		cout << "\nNo movies in the system.\n";
		return;
	}
	cout << "\nMovies List:\n";
	cout << left << setw(5) << "No."
	     << setw(20) << "Title"
	     << setw(15) << "Genre"
	     << setw(8) << "Rating"
	     << setw(8) << "Year"
	     << setw(10) << "Duration"
	     << setw(12) << "Watch Count" << "\n";
	cout << "--------------------------------------------------------------------\n";
	for (size_t i = 0; i < movies.size(); ++i) {
		cout << left << setw(5) << (i + 1)
		     << setw(20) << movies[i]->title
		     << setw(15) << movies[i]->genre
		     << setw(8) << movies[i]->rating
		     << setw(8) << movies[i]->year
		     << setw(10) << movies[i]->duration
		     << setw(12) << movies[i]->watchcount << "\n";
	}
	cout << "--------------------------------------------------------------------\n";
	cout << "Total movies: " << movies.size() << endl;
}



//======Watchnig functions=============
void moveToTopIfExists(Movie* selected, MovieHashtable& movieTable) {
	StackNode* prev = nullptr;
	StackNode* curr = watchHistoryTop;
	while (curr != nullptr) {
		if (curr->movie == selected) {
			if (prev == nullptr) return;
			prev->next = curr->next;
			curr->next = watchHistoryTop;
			watchHistoryTop = curr;
			cout << "Moved to top of watch history: " << selected->title << endl;
			return;
		}
		prev = curr;
		curr = curr->next;
	}
	StackNode* newNode = new StackNode(selected);
	newNode->next = watchHistoryTop;
	watchHistoryTop = newNode;
	movieTable.incrementWatchcount(selected->title);
	cout << "Movie Watched : " << selected->title << endl;
}

void pushHistoryByIndex(MovieHashtable& movieTable) {
	vector<Movie*> movies = movieTable.getAllMovies();
	if (movies.empty()) {
		cout << "\nNo movies available.\n";
		return;
	}
	displayMovies(movieTable);
	int choice = getValidatedInt("Enter the movie number to watch: ", 1, movies.size());
	Movie* selected = movies[choice - 1];
	moveToTopIfExists(selected, movieTable);
}

void removeTopHistory() {
	if (watchHistoryTop == nullptr) {
		cout << "\nWatch history is already empty.\n";
		return;
	}
	StackNode* temp = watchHistoryTop;
	watchHistoryTop = watchHistoryTop->next;
	cout << "Removed from watch history: " << temp->movie->title << endl;
	delete temp;
}

void removeSpecificHistory() {
	if (watchHistoryTop == nullptr) {
		cout << "\nWatch history is empty.\n";
		return;
	}
	string titleToRemove = getValidatedString("Enter the title of the movie to remove from history: ");
	StackNode* curr = watchHistoryTop;
	StackNode* prev = nullptr;
	while (curr != nullptr) {
		if (curr->movie->title == titleToRemove) {
			if (prev == nullptr) {
				watchHistoryTop = curr->next;
			} else {
				prev->next = curr->next;
			}
			cout << "Movie \"" << titleToRemove << "\" removed from watch history.\n";
			delete curr;
			return;
		}
		prev = curr;
		curr = curr->next;
	}
	cout << "Movie not found in watch history.\n";
}

void displayHistory() {
	if (watchHistoryTop == nullptr) {
		cout << "\nNo movies in watch history.\n";
		return;
	}
	StackNode* temp = watchHistoryTop;
	cout << "\nWatch History (Most Recent First):\n";
	cout << left << setw(20) << "Title"
	     << setw(15) << "Genre"
	     << setw(8) << "Rating"
	     << setw(8) << "Year"
	     << setw(10) << "Duration" << "\n";
	cout << "---------------------------------------------------------------\n";
	while (temp != nullptr) {
		cout << left << setw(20) << temp->movie->title
		     << setw(15) << temp->movie->genre
		     << setw(8) << temp->movie->rating
		     << setw(8) << temp->movie->year
		     << setw(10) << temp->movie->duration << "\n";
		temp = temp->next;
	}
	cout << "---------------------------------------------------------------\n";
}

void editMovieDetails(MovieHashtable& movieTable) {
	string title = getValidatedString("Enter the title of the movie to edit: ");
	Movie* movie = movieTable.findMovie(title);
	if (!movie) {
		cout << "Movie not found.\n";
		return;
	}

	cout << "Editing: " << movie->title << "\n";
	cout << "1. Edit Genre\n2. Edit Rating\n3. Edit Year\n4. Edit Duration\nChoose what to edit: ";
	int choice;
	cin >> choice;
	cin.ignore();

	switch (choice) {
		case 1:
			movie->genre = getValidatedString("Enter new genre: ");
			break;
		case 2:
			movie->rating = getValidatedRating();
			break;
		case 3:
			movie->year = getValidatedInt("Enter new release year (1900ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Å“2025): ", 1900, 2025);
			break;
		case 4:
			movie->duration = getValidatedInt("Enter new duration (10-180 mins): ", 10, 180);
			break;
		default:
			cout << "Invalid choice.\n";
	}
}



//=======Admin authentication============
bool authenticateAdmin(const string& passwordFile = "admin.txt") {
	ifstream fin(passwordFile);
	if (!fin) {
		cout << "Admin password file not found.\n";
		return false;
	}

	string storedPass;
	getline(fin, storedPass);
	fin.close();

	cin.ignore(numeric_limits<streamsize>::max(), '\n');
	string enteredPass;
	cout << "Enter admin password: ";
	getline(cin, enteredPass);

	if (enteredPass == storedPass) {
		cout << "Admin authenticated.\n";
		return true;
	} else {
		cout << "Incorrect password. Access denied.\n";
		return false;
	}
}




//=======Menu-driven system==============
void runMovieSystem() {
	MovieHashtable movieTable;
	AVLTree avlRating(true);
	AVLTree avlYear(false);
	Graph graph;
	int nextId = 1;
	int choice;


	loadMoviesFromFile("Movies.txt", nextId, movieTable, avlRating, avlYear, graph);


	do {
		cout << "\n--- Netflix Movie Recommendation System ---\n";
		cout << "1. Insert a Movie\n";
		cout << "2. Display All Movies\n";
		cout << "3. Edit a Movie\n";
		cout << "4. Watch a movie\n";
		cout << "5. Show Watch History\n";
		cout << "6. Remove Top Movie from Watch History\n";
		cout << "7. Remove Specific Movie from Watch History\n";
		cout << "8. Filter Movies by Year Range\n";
		cout << "9. Filter Movies by Rating Range\n";
		cout << "10. Show Latest N Movies\n";
		cout << "11. Filter Movies by Genre\n";
		cout << "12. Combined Filter (Genre + Rating + Year)\n";
		cout << "13. Recommend Similar Movies (BFS)\n";
		cout << "14. Recommend Similar Movies (Dijkstra)\n";
		cout << "15. Recommend Movies by Title Prefix\n";
		cout << "16. Exit\n";
		cout << "Enter your choice: ";
		cin >> choice;
		if (cin.fail()) {
			cin.clear();
			cin.ignore(1000, '\n');
			cout << "Invalid input. Please enter a number.\n";
			continue;
		}
		switch (choice) {
			case 1:
				if (authenticateAdmin()) {
					insertMovie(nextId, movieTable, avlRating, avlYear, graph);
					saveMoviesToFile("movies.txt", movieList);
				}
				break;
			case 2:
				displayMovies(movieTable);
				break;
			case 3:
				if(authenticateAdmin()) {
					editMovieDetails(movieTable);
					saveMoviesToFile("movies.txt", movieList);

				}
				break;
			case 4:
				pushHistoryByIndex(movieTable);
				break;
			case 5:
				displayHistory();
				break;
			case 6:
				removeTopHistory();
				break;
			case 7:
				removeSpecificHistory();
				break;
			case 8: {
				int startYear = getValidatedInt("Start year: ", 1900, 2025);
				int endYear = getValidatedInt("End year: ", startYear, 2025);
				avlYear.filterByYearRange(startYear, endYear);
				break;
			}
			case 9: {
				float minRating = getValidatedRating();
				float maxRating = getValidatedRating();
				if (maxRating < minRating) swap(minRating, maxRating);
				avlRating.filterByRatingRange(minRating, maxRating);
				break;
			}
			case 10: {
				int N = getValidatedInt("Number of latest movies: ", 1, 100);
				avlYear.filterLatestMovies(N);
				break;
			}
			case 11: {
				string genre = getValidatedString("Genre: ");
				avlYear.filterByGenre(genre);
				break;
			}
			case 12: {
				string genre = getValidatedString("Genre: ");
				float minRating = getValidatedRating();
				float maxRating = getValidatedRating();
				if (maxRating < minRating) swap(minRating, maxRating);
				int startYear = getValidatedInt("Start year: ", 1900, 2025);
				int endYear = getValidatedInt("End year: ", startYear, 2025);
				avlYear.combinedFilter(genre, minRating, maxRating, startYear, endYear);
				break;
			}
			case 13: {
				string title = getValidatedString("Movie title: ");
				int count = getValidatedInt("Number of recommendations(1-10): ", 1, 10);
				graph.recommendSimilarMoviesBFS(title, count);
				break;
			}
			case 14: {
				string title = getValidatedString("Movie title: ");
				int count = getValidatedInt("Number of recommendations(1-10): ", 1, 10);
				graph.recommendSimilarMoviesDijkstra(title, count);
				break;
			}
			case 15: {
				string prefix = getValidatedString("Enter title prefix: ");
				int limit = getValidatedInt("Number of recommendations: ", 1, 10);
				vector<Movie*> recs = movieTable.getRecommendations(prefix, limit);

				if (recs.empty()) {
					cout << "No movies found with prefix '" << prefix << "'.\n";
					break;
				}

				cout << "Sort recommendations by:\n1. Watchcount\n2. Rating\nChoose: ";
				int sortChoice;
				cin >> sortChoice;
				cin.ignore(numeric_limits<streamsize>::max(), '\n');

				if (sortChoice == 1) {
					sort(recs.begin(), recs.end(), [](Movie* a, Movie* b) {
						return a->watchcount > b->watchcount;
					});
				} else if (sortChoice == 2) {
					sort(recs.begin(), recs.end(), [](Movie* a, Movie* b) {
						return a->rating > b->rating;
					});
				} else {
					cout << "Invalid choice.\n";
					break;
				}

				cout << "\nRecommendations for prefix '" << prefix << "':\n";
				for (auto m : recs) {
					cout << "- " << m->title << " (Watched: " << m->watchcount
					     << ", Rating: " << m->rating << ", Year: " << m->year << ")\n";
				}
				break;
			}

			case 16:
				saveMoviesToFile("Movies.txt", movieList);

				cout << "Exiting program.\n";


				break;
			default:
				cout << "Invalid choice. Please try again.\n";
		}
	} while (choice != 16);

}


//===Starting point of program=======
int main() {
	runMovieSystem();
	return 0;
}
